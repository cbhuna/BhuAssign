package com.cts.patientmanagement;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;
import java.util.TreeSet;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.patientmanagement.entity.ClinicalData;
import com.cts.patientmanagement.entity.ComponentType;
import com.cts.patientmanagement.entity.Patient;
import com.cts.patientmanagement.repos.PatientRepo;

@SpringBootTest
class PatientmanagementRestApiApplicationTests {

	@Autowired
	PatientRepo pRepo;

	@Test
	void contextLoads() {
		Patient p1 = new Patient(3L, "TestFN", "TestLN", 30, new TreeSet<ClinicalData>());
		ClinicalData c1 = new ClinicalData(1L, ComponentType.HEIGHT, "55", LocalDateTime.now(), p1);
		p1.getClinicals().add(c1);
		pRepo.save(p1);
		
		ClinicalData c2 = new ClinicalData(3L, ComponentType.WEIGHT, "55", LocalDateTime.now(), p1);
		p1.getClinicals().add(c2);
		pRepo.save(p1);
		
		ClinicalData c3 = new ClinicalData(3L, ComponentType.BMI, "20", LocalDateTime.now(), p1);
		p1.getClinicals().add(c3);
		pRepo.save(p1);

		assertNotNull(pRepo.findById(3L).get());
	}

}
