package com.cts.patientmanagement.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.patientmanagement.entity.Patient;
import com.cts.patientmanagement.exceptions.InvalidDataException;
import com.cts.patientmanagement.exceptions.NotFoundException;
import com.cts.patientmanagement.services.PatientService;

@RestController
@RequestMapping("/patient")
public class PatientController {

	@Autowired
	private PatientService service;
	/**
	 * Method to initiate create a patient
	 * @param patient
	 * @param results
	 * @return Patient record with response code
	 * @throws InvalidDataException
	 */
	@PostMapping
	public ResponseEntity<Patient> createPatient(@RequestBody @Valid Patient patient, BindingResult results)
			throws InvalidDataException {
		return savePatient(patient, results, "CREATE");
	}
	/**
	 * Method to create and update patient record
	 * @param patient
	 * @param results
	 * @param option
	 * @return
	 * @throws InvalidDataException
	 */
	private ResponseEntity<Patient> savePatient(Patient patient, BindingResult results, String option)
			throws InvalidDataException {
		if (results.hasErrors()) {
			String errorMessages = results.getAllErrors().stream().map(ObjectError::getDefaultMessage)
					.reduce((m1, m2) -> m1 + "," + m2).orElse("");
			throw new InvalidDataException(errorMessages);
		}
		patient = service.savePatient(patient);
		ResponseEntity<Patient> re = null;
		if (option.equals("CREATE")) {
			re = new ResponseEntity<Patient>(patient, HttpStatus.CREATED);
		} else {
			re = new ResponseEntity<Patient>(patient, HttpStatus.ACCEPTED);
		}
		return re;
	}
	/**
	 * Retrieve patient record based on patient id
	 * @param id
	 * @return Patient record with response code
	 * @throws NotFoundException
	 */
	@GetMapping("/{pId}")
	public ResponseEntity<Patient> getPatient(@PathVariable("pId") Long id) throws NotFoundException {
		Patient patient = service.getPatientById(id);
		if (patient == null) {
			throw new NotFoundException("No record found for given id");
		}
		return new ResponseEntity<Patient>(service.getPatientById(id), HttpStatus.OK);
	}
	/**
	 * To retrieve all patients 
	 * @return List of patients with response code
	 */
	@GetMapping
	public ResponseEntity<List<Patient>> getAllPatient() {
		return new ResponseEntity<List<Patient>>(service.getAllPatients(), HttpStatus.OK);
	}
	
	/**
	 * Update patient record base on patient id
	 * @param patient
	 * @param pId
	 * @param results
	 * @return Updated patient record with response code
	 * @throws InvalidDataException
	 * @throws NotFoundException
	 */
	@PutMapping("/{pId}")
	public ResponseEntity<Patient> updatePatient(@RequestBody @Valid Patient patient, @PathVariable long pId,
			BindingResult results) throws InvalidDataException, NotFoundException {
		Patient existingPatient = service.getPatientById(pId);
		if (existingPatient != null && existingPatient.getpId() != null) {
			patient.setpId(existingPatient.getpId());
			return savePatient(patient, results, "UPDATE");
		} else {
			throw new NotFoundException("No record found for given id");
		}
	}
	
	/**
	 * Delete a patient record based on patient id
	 * @param pId
	 * @return Response message and code
	 * @throws NotFoundException
	 */
	@DeleteMapping("/{pId}")
	public ResponseEntity<?> deletePatientById(@PathVariable long pId) throws NotFoundException {
		if (service.getPatientById(pId) != null) {
			service.deletePatient(pId);
			return new ResponseEntity<>("Patient deleted successfully", HttpStatus.OK);
		} else {
			throw new NotFoundException("No Record Found! Invalid Id!");
		}

	}

}
