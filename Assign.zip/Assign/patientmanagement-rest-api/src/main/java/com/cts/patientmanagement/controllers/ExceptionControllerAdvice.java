package com.cts.patientmanagement.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.patientmanagement.exceptions.InvalidDataException;
import com.cts.patientmanagement.exceptions.NotFoundException;

@RestControllerAdvice
public class ExceptionControllerAdvice {

	private Logger logger;

	public ExceptionControllerAdvice() {
		this.logger = LoggerFactory.getLogger(this.getClass());
	}

	@ExceptionHandler(InvalidDataException.class)
	public ResponseEntity<String> handleInvalidDataException(InvalidDataException exp) {
		logger.debug(exp.getMessage(), exp);
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<String> handleNotFoundException(NotFoundException exp) {
		logger.debug(exp.getMessage(), exp);
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		logger.error(exp.getMessage(), exp);
		return new ResponseEntity<String>("Some Server Side Error! Please Retry!", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
