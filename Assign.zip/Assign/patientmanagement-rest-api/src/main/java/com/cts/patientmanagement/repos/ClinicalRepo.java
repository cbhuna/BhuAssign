package com.cts.patientmanagement.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.patientmanagement.entity.ClinicalData;

public interface ClinicalRepo extends JpaRepository<ClinicalData, Long>{
	@Query("SELECT c FROM ClinicalData c WHERE c.patient.pId=:pId")
	List<ClinicalData> getClinicalDataByPatientId(Long pId);

}
