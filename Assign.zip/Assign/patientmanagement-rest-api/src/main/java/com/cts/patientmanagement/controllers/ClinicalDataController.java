package com.cts.patientmanagement.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.patientmanagement.entity.ClinicalData;
import com.cts.patientmanagement.entity.Patient;
import com.cts.patientmanagement.exceptions.InvalidDataException;
import com.cts.patientmanagement.exceptions.NotFoundException;
import com.cts.patientmanagement.services.ClinicalDataService;
import com.cts.patientmanagement.services.PatientService;

@RestController
@RequestMapping("/clinical")
public class ClinicalDataController {

	@Autowired
	private ClinicalDataService service;

	@Autowired
	private PatientService patientService;
	
	/**
	 * Method to retrieve all clinical records for a patient with id
	 * @param pId
	 * @return List of clinical records for a patient and /or response code
	 * @throws NotFoundException
	 */
	@GetMapping("/{pId}")
	public ResponseEntity<List<ClinicalData>> getClinicalDataForPatient(@PathVariable Long pId)
			throws NotFoundException {
		Patient patient = patientService.getPatientById(pId);
		if (patient == null) {
			throw new NotFoundException("No Patient Record Found For Given Id");
		} else {
			List<ClinicalData> clinicals = service.getClinicalDataByPatientId(patient.getpId());
			if (clinicals == null || clinicals.size() == 0) {
				throw new NotFoundException("No Clinical Record Found For Given Id");
			} else
				return new ResponseEntity<List<ClinicalData>>(clinicals, HttpStatus.OK);
		}
	}
	/**
	 * Method to initiate creating clinical record
	 * @param clinical
	 * @param results
	 * @return Clinical record with response code
	 * @throws InvalidDataException
	 */
	@PostMapping
	public ResponseEntity<ClinicalData> createClinicalData(@RequestBody @Valid ClinicalData clinical,
			BindingResult results) throws InvalidDataException {
		return saveClinical(clinical, results, "CREATE");
	}
	/**
	 * Method used to save or update clinical data
	 * @param clinical
	 * @param results
	 * @param option
	 * @return ClinicalData record with status response code
	 * @throws InvalidDataException
	 */
	private ResponseEntity<ClinicalData> saveClinical(ClinicalData clinical, BindingResult results, String option)
			throws InvalidDataException {
		if (results.hasErrors()) {
			String errorMessages = results.getAllErrors().stream().map(ObjectError::getDefaultMessage)
					.reduce((m1, m2) -> m1 + "," + m2).orElse("");
			throw new InvalidDataException(errorMessages);
		}
		clinical = service.saveClinicalData(clinical);
		ResponseEntity<ClinicalData> re = null;
		if (option.equals("CREATE")) {
			re = new ResponseEntity<ClinicalData>(clinical, HttpStatus.CREATED);
		} else {
			re = new ResponseEntity<ClinicalData>(clinical, HttpStatus.ACCEPTED);
		}
		return re;
	}
	/**
	 * Method to update clinical record based on clinical id
	 * @param clinical
	 * @param id
	 * @param results
	 * @return Updated clinical record with response code
	 * @throws InvalidDataException
	 * @throws NotFoundException
	 */
	@PutMapping("/{id}")
	public ResponseEntity<ClinicalData> updateClinicalData(@RequestBody @Valid ClinicalData clinical,
			@PathVariable long id, BindingResult results) throws InvalidDataException, NotFoundException {

		ClinicalData existingClinical = service.getClinicalDataById(id);
		if (existingClinical != null && existingClinical.getId() != null) {
			clinical.setId(existingClinical.getId());
			return saveClinical(clinical, results, "UPDATE");
		} else {
			throw new NotFoundException("No record found for given id");
		}
	}
}
