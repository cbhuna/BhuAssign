package com.cts.patientmanagement.services;

import java.util.List;

import com.cts.patientmanagement.entity.ClinicalData;

public interface ClinicalDataService {
	ClinicalData saveClinicalData(ClinicalData clinical);
	ClinicalData getClinicalDataById(Long id);
	List<ClinicalData> getAllClinicalData();
	void deleteClinicalData(Long id);
	List<ClinicalData> getClinicalDataByPatientId(Long id);
}
