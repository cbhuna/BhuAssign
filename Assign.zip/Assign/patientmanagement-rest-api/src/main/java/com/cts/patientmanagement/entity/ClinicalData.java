package com.cts.patientmanagement.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "clinicaldatas")
public class ClinicalData implements Comparable<ClinicalData>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@NotNull(message = "Component Name is mandate and can be HEIGHT/WEIGHT/BMI")
	private ComponentType componentName;
	@NotNull(message = "Component Value is a mandatory field")
	private String componentValue;
	@NotNull(message = "Measured Date and Time is a mandatory field")
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime measuredDateTime;
	
	@ManyToOne
	@JsonProperty(access = Access.WRITE_ONLY) // patient details will not be fetched to response
	private Patient patient;
	
	public ClinicalData() {
		
	}
	

	public ClinicalData(Long id,
			@NotNull(message = "Component Name is mandate and can be HEIGHT/WEIGHT/BMI") ComponentType componentName,
			@NotNull(message = "Component Value is a mandatory field") String componentValue,
			@NotNull(message = "Measured Date and Time is a mandatory field") LocalDateTime measuredDateTime,
			Patient patient) {
		super();
		this.id = id;
		this.componentName = componentName;
		this.componentValue = componentValue;
		this.measuredDateTime = measuredDateTime;
		this.patient = patient;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ComponentType getComponentName() {
		return componentName;
	}

	public void setComponentName(ComponentType componentName) {
		this.componentName = componentName;
	}

	public String getComponentValue() {
		return componentValue;
	}

	public void setComponentValue(String componentValue) {
		this.componentValue = componentValue;
	}

	public LocalDateTime getMeasuredDateTime() {
		return measuredDateTime;
	}

	public void setMeasuredDateTime(LocalDateTime measuredDateTime) {
		this.measuredDateTime = measuredDateTime;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	@Override
	public String toString() {
		return "ClinicalData [id=" + id + ", componentName=" + componentName + ", componentValue=" + componentValue
				+ ", measuredDateTime=" + measuredDateTime + ", patient=" + patient + "]";
	}
	
	@Override
	public int compareTo(ClinicalData o) {
		return this.id ==null?1:this.id.compareTo(o.id);
	}

}
