package com.cts.patientmanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.patientmanagement.entity.Patient;
import com.cts.patientmanagement.repos.PatientRepo;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepo dao;

	@Override
	public Patient savePatient(Patient patient) {
		return dao.save(patient);
	}

	@Override
	public Patient getPatientById(Long id) {
		return dao.findById(id).orElse(null);
	}

	@Override
	public List<Patient> getAllPatients() {
		return dao.findAll();
	}

	@Override
	public void deletePatient(Long id) {
		dao.deleteById(id);
	}

}
