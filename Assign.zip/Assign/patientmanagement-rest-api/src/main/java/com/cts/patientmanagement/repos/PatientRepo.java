package com.cts.patientmanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.patientmanagement.entity.Patient;

public interface PatientRepo extends JpaRepository<Patient, Long> {
}
