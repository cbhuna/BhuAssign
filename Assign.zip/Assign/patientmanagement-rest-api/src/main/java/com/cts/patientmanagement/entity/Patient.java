package com.cts.patientmanagement.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="patients")
public class Patient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pId;
	
	@NotNull(message = "First Name is a mandatory field")
	@NotBlank(message="First Name cannot be blank")
	private String firstName;
	
	@NotNull(message = "Last Name is a mandatory field")
	@NotBlank(message="First Name cannot be blank")
	private String lastName;
	
	@NotNull(message = "Age is a mandatory field")
	private int age;
	
	@OneToMany(mappedBy="patient", cascade = CascadeType.ALL)
	private Set<ClinicalData> clinicals;
	
	
	public Set<ClinicalData> getClinicals() {
		return clinicals;
	}

	public void setClinicals(Set<ClinicalData> clinicals) {
		this.clinicals = clinicals;
	}

	public Patient(Long pId,
			@NotNull(message = "First Name is a mandatory field") @NotBlank(message = "First Name cannot be blank") String firstName,
			@NotNull(message = "Last Name is a mandatory field") @NotBlank(message = "First Name cannot be blank") String lastName,
			@NotNull(message = "Age is a mandatory field") int age, Set<ClinicalData> clinicals) {
		super();
		this.pId = pId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.clinicals = clinicals;
	}

	public Patient() {
		super();
	}

	public Long getpId() {
		return pId;
	}

	public void setpId(Long pId) {
		this.pId = pId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Patient [id=" + pId + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + "]";
	}
}
