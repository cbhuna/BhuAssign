package com.cts.patientmanagement.services;

import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.patientmanagement.entity.ClinicalData;
import com.cts.patientmanagement.entity.ComponentType;
import com.cts.patientmanagement.repos.ClinicalRepo;

@Service
public class ClinicalDataServiceImpl implements ClinicalDataService {

	@Autowired
	private ClinicalRepo dao;

	@Override
	public ClinicalData saveClinicalData(ClinicalData clinical) {
		ClinicalData savedClinical = dao.save(clinical);
		if(clinical.getComponentName().equals(ComponentType.BMI)) {
			savedClinical.setComponentValue(bmiCalculation(savedClinical));
			return dao.save(savedClinical);
		}
		return savedClinical;
	}

	private String bmiCalculation(ClinicalData savedClinical) {
		List<ClinicalData> cList = getClinicalDataByPatientId(savedClinical.getPatient().getpId());
		double height = 0;
		double weight = 0;
		String bmi = "0";
		for (Iterator<ClinicalData> iterator = cList.iterator(); iterator.hasNext();) {
			ClinicalData cData = (ClinicalData) iterator.next();
			if(cData.getComponentName().equals(ComponentType.HEIGHT)){
				height = Double.parseDouble(cData.getComponentValue());
			}else if(cData.getComponentName().equals(ComponentType.WEIGHT)){
				weight = Double.parseDouble(cData.getComponentValue());
			}
		}
		if(height != 0) {
			DecimalFormat df = new DecimalFormat("0.00");
			bmi = df.format(weight / (height * height));
		}
		return bmi;
	}

	@Override
	public ClinicalData getClinicalDataById(Long id) {
		return dao.findById(id).orElse(null);
	}
	
	@Override
	public List<ClinicalData> getClinicalDataByPatientId(Long pId){
		return dao.getClinicalDataByPatientId(pId);
	}
	
	@Override
	public List<ClinicalData> getAllClinicalData() {
		return dao.findAll();
	}

	@Override
	public void deleteClinicalData(Long id) {
		dao.deleteById(id);
	}
}
