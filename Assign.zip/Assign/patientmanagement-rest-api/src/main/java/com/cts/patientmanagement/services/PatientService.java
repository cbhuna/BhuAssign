package com.cts.patientmanagement.services;

import java.util.List;

import com.cts.patientmanagement.entity.Patient;

public interface PatientService {
	Patient savePatient(Patient patient);
	Patient getPatientById(Long id);
	List<Patient> getAllPatients();
	void deletePatient(Long id);
}
