package com.cts.patientmanagement.entity;

public enum ComponentType {
		HEIGHT,WEIGHT,BMI
}
