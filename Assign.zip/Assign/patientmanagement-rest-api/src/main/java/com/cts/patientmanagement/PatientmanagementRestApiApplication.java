package com.cts.patientmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientmanagementRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientmanagementRestApiApplication.class, args);
	}

}
